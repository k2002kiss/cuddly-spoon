using PVZHE.ModEditor.ModSystem;

namespace CactusTune
{
    public sealed class Entry : IXWModRuntimeEntry
    {
        public void Initialize(XWModRuntimeContext context)
        {
            System.Console.WriteLine("CACTUS_TUNE_INIT api=" + context.ApiVersion);
        }

        public void OnAllModsLoaded()
        {
            System.Console.WriteLine("CACTUS_TUNE_LOADED");
        }

        public void Shutdown()
        {
            System.Console.WriteLine("CACTUS_TUNE_SHUTDOWN");
        }
    }
}
